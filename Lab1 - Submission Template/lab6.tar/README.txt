Lab 6 README
==========================================================

LEADER
mrubi005@ucr.edu

MEMBERS
==========================================================
mrubi005@ucr.edu

REMARKS
- CAM's are really cool they are like the opposite of RAM memory
- In this lab we implemented the CAM and created some HDL to automaticaly generate an arbitrary sized CAM. 
- I'm not 100% sure what the output of the cam was supposed to look like with the provided TEST bench bunch i believe my CAM works fine.
- There does seem to be a bit of lag time before the output sees the results which might have something to do with a bug in my code probably regarding my clock signal
- I attached an image of my result to this folder
==========================================================

BUGS IF ANY 
- there might be some timing issues since there seems to take a little bit of time before the correct output is seen. Probably has to do with my clock signal if thats the case. Im not sure how soon the output is supposed to be seend.



==========================================================

ORIGINAL WORK STATEMENT
- I certify that this submission represents my own original work. This submission was not done in collaboration nor was any substanial portion of the code obtained from third parties, including websites and the like.
