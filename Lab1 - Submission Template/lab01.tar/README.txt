Lab 1 README
==========================================================

LEADER
mrubi005@ucr.edu

MEMBERS
==========================================================
mrubi005@ucr.edu

REMARKS
- There is a lot to pick up in this first lab since we are working with a new language. The lab was prity streight forward most of the time was spent in understanding and implementation.
- This code could be further improved by changing the organasation and layout. This is not optimal due to lack of experience with VHDL

==========================================================

BUGS IF ANY 
- The ALU worked fine with the provided test bench. It might need some edge cases but it took some time to try and figure those out.



==========================================================

ORIGINAL WORK STATEMENT
- I certify that this submission represents my own original work. This submission was not done in collaboration nor was any substanial portion of the code obtained from third parties, including websites and the like.
