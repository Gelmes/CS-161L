Lab 3 README
==========================================================

LEADER
mrubi005@ucr.edu

MEMBERS
==========================================================
mrubi005@ucr.edu

REMARKS
- The test benches used were very basic so no special cases were found right away
==========================================================

BUGS IF ANY 
- When running cirtain cases where the values for the function on the ALU are "X's" meaning either zero or one, the code will not work for other values other then zero. In other words my code assumes all "X's" from the lab guide are the value of zero.

==========================================================

ORIGINAL WORK STATEMENT
- I certify that this submission represents my own original work. This submission was not done in collaboration nor was any substanial portion of the code obtained from third parties, including websites and the like.
